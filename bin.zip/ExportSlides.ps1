param ($inputFile, $imageType, [switch]$replace=$false)
# Powershell script to export Powerpoint slides as images using the Powerpoint COM API

# export Powerpoint slides as images
function Export-Slides($inputFile, $imageType)
{
    Write-Host Export $inputFile as $imageType
    # Load Powerpoint Interop Assembly
    [Reflection.Assembly]::LoadWithPartialname("Microsoft.Office.Interop.Powerpoint") > $null
    [Reflection.Assembly]::LoadWithPartialname("Office") > $null

    $msoFalse =  [Microsoft.Office.Core.MsoTristate]::msoFalse
    $msoTrue =  [Microsoft.Office.Core.MsoTristate]::msoTrue

    # start Powerpoint
    $application = New-Object "Microsoft.Office.Interop.Powerpoint.ApplicationClass" 

    # Make sure inputFile is an absolute path
    $inputFile = Resolve-Path $inputFile

    $presentation = $application.Presentations.Open($inputFile, $msoTrue, $msoFalse, $msoFalse)

    $slideCnt = $presentation.Slides.Count
    if ($slideCnt -gt 0)
    {
        $outputParent = Split-Path $inputFile -Parent
        $outputBaseName = (Get-Item $inputFile).BaseName
        $outputLoc = Join-Path -Path $outputParent -ChildPath $outputBaseName
        if ($imageType -eq "png")
        {
            if (Test-Path -Path $outputLoc)
            {
                if ($replace)
                {
                    Write-Host Deleting existing directory named $outputLoc
                    Remove-Item -Path $outputLoc -Recurse
                }
                else
                {
                    # Don't replace an existing directory
                    Write-Host Skipping export, there is an existing directory named $outputLoc
                    return
                }
            }

            Write-Host Creating a directory $outputLoc with $slideCnt "png" files.
            New-Item -Path $outputParent -Name $outputBaseName -ItemType "directory"
            for ($slideNumber = 1; $slideNumber -le $slideCnt; $slideNumber++)
            {
                $outputSlideName = "Slide" + $slideNumber + "." + $imageType
                $outputFile = Join-Path -Path $outputLoc -ChildPath $outputSlideName
                $slide = $presentation.Slides.Item($slideNumber)
                $slide.Export($outputFile, $imageType)
                $slide = $null
            }
        }
        elseif ($imageType -eq "mp4s")
        {
            $imageType = "mp4"
            if (Test-Path -Path $outputLoc)
            {
                if ($replace)
                {
                    Write-Host Deleting existing directory named $outputLoc
                    Remove-Item -Path $outputLoc -Recurse
                }
                else
                {
		    # Overwriting could be useful if the existing directory has png files and not mp4s
                    Write-Host Overwriting existing directory named $outputLoc
                }
            }
            # Hide all slides
            for ($slideNumber = 1; $slideNumber -le $slideCnt; $slideNumber++)
            {
                $presentation.Slides($slideNumber).SlideShowTransition.Hidden = $msoTrue
            }

            Write-Host Creating a directory $outputLoc with $slideCnt "mp4" files.
            New-Item -Path $outputParent -Name $outputBaseName -ItemType "directory"
            for ($slideNumber = 1; $slideNumber -le $slideCnt; $slideNumber++)
            {
                $presentation.Slides($slideNumber).SlideShowTransition.Hidden = $msoFalse
                $outputSlideName = "Slide" + $slideNumber + "." + $imageType
                $outputFile = Join-Path -Path $outputLoc -ChildPath $outputSlideName
                Write-Host Creating a video file named $outputFile
                $presentation.SaveAs($outputFile, 39)
                $createStatus = $presentation.CreateVideoStatus
                While ($createStatus -eq 1) # 1=busy, 3=done
                {
                    Write-Host -NoNewline .
                    Start-Sleep -Seconds 10
                    $createStatus = $presentation.CreateVideoStatus
                }
                if ($createStatus -ne 3) # 1=busy, 3=done
                {
                    Start-Sleep -Seconds 10
                }
                Write-Host .
                $presentation.Slides($slideNumber).SlideShowTransition.Hidden = $msoTrue
            }
            Write-Host Done
            Start-Sleep -Seconds 5
        }
        elseif ($imageType -eq "mp4")
        {
            $outputFile = $outputLoc + "." + $imageType

            if (Test-Path -Path $outputFile)
            {
                if ($replace)
                {
                    Write-Host Deleting existing video file named $outputFile
                    Remove-Item -Path $outputFile
                }
                else
                {
                    Write-Host Skipping export, there is an existing video file named $outputFile
                    return
                }
            }

            Write-Host Creating a video file named $outputFile
            $presentation.SaveAs($outputFile, 39)
            $createStatus = $presentation.CreateVideoStatus
            While ($createStatus -eq 1) # 1=busy, 3=done
            {
                Write-Host -NoNewline .
                Start-Sleep -Seconds 10
                $createStatus = $presentation.CreateVideoStatus
            }
            Write-Host .
        }
    }
    $presentation.Close()
    $presentation = $null
    
    if($application.Windows.Count -eq 0)
    {
        $application.Quit()
    }
    
    $application = $null
    
    # Make sure references to COM objects are released, otherwise powerpoint might not close
    # (calling the methods twice is intentional, see https://msdn.microsoft.com/en-us/library/aa679807(office.11).aspx#officeinteroperabilitych2_part2_gc)
    [System.GC]::Collect();
    [System.GC]::WaitForPendingFinalizers();
    [System.GC]::Collect();
    [System.GC]::WaitForPendingFinalizers();       
}

# Prompts user for input file
Function Get-FileName($initialDirectory)
{  
    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null

    $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $OpenFileDialog.initialDirectory = $initialDirectory
    $OpenFileDialog.filter = "PowerPoint Presentation (*.pptx)| *.pptx"
    $OpenFileDialog.ShowDialog() | Out-Null
    $OpenFileDialog.filename # returns selected filename
}

# Tries to determine image type from input file name, otherwise returns "select"
Function Auto-Select-ImageType($inputFile)
{
    $retType = "select" # default to "select" if strings are not found
    # file name contains "Service Slides" -> mp4s
    if ($inputFile -like '*Service Slides*')
    {
        $retType = "mp4s"
    }
    # file name contains "Timed Slides" -> mp4
    if ($inputFile -like '*Timed Slides*')
    {
        $retType = "mp4"
    }
    $retType # returns image type
}

# Prompts user for image type
Function Select-ImageType($inputFile)
{
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'Select Type of Image(s) to Create'
    $form.Size = New-Object System.Drawing.Size(420,220)
    $form.StartPosition = 'CenterScreen'

    $okButton = New-Object System.Windows.Forms.Button
    $okButton.Location = New-Object System.Drawing.Point(75,140)
    $okButton.Size = New-Object System.Drawing.Size(75,23)
    $okButton.Text = 'OK'
    $okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $form.AcceptButton = $okButton
    $form.Controls.Add($okButton)

    $cancelButton = New-Object System.Windows.Forms.Button
    $cancelButton.Location = New-Object System.Drawing.Point(220,140)
    $cancelButton.Size = New-Object System.Drawing.Size(75,23)
    $cancelButton.Text = 'Cancel'
    $cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $form.CancelButton = $cancelButton
    $form.Controls.Add($cancelButton)

    $label = New-Object System.Windows.Forms.Label
    $label.Location = New-Object System.Drawing.Point(10,20)
    $label.Size = New-Object System.Drawing.Size(280,20)
    $label.Text = 'Please select an image type to create from:'
    $form.Controls.Add($label)

    $fileLabel = New-Object System.Windows.Forms.Label
    $fileLabel.Location = New-Object System.Drawing.Point(10,40)
    $fileLabel.Size = New-Object System.Drawing.Size(280,20)
    $inputFileName = Split-Path $inputFile -leaf
    $fileLabel.Text = $inputFileName
    $form.Controls.Add($fileLabel)

    $listBox = New-Object System.Windows.Forms.ListBox
    $listBox.Location = New-Object System.Drawing.Point(10,60)
    $listBox.Size = New-Object System.Drawing.Size(350,20)
    $listBox.Height = 70

    [void] $listBox.Items.Add('png  - Generate a PNG image file for each slide in the PowerPoint')
    [void] $listBox.Items.Add('mp4  - Generate a MP4 video for the entire PowerPoint')
    [void] $listBox.Items.Add('mp4s - Generate a MP4 video for each slide in the PowerPoint')

    $form.Controls.Add($listBox)

    $form.Topmost = $true

    $result = $form.ShowDialog()

    if ($result -eq [System.Windows.Forms.DialogResult]::OK)
    {
        $imageTypeSelected = $listBox.SelectedItem
        $retTypeSel = $imageTypeSelected -Split ' '
        if ($retTypeSel.count -gt 0)
        {
            $retTypeSel[0] # returns selected image type
        }
        $retTypeSel = $null
    }
}

# Validate Parameters
$parmsValid = $true
# Set default directory
$thisWeekDir = "C:\Dropbox\Media\ThisWeek"
if (-not (Test-Path $thisWeekDir))
{
    $thisWeekDir = "D:\Dropbox\Media\ThisWeek"
}
# Ensure we have a input file
if (($inputFile.Length -eq 0) -or ($inputFile -eq "none"))
{
    $inputFile = Get-FileName($thisWeekDir)
    if ($inputFile.Length -eq 0)
    {
        $parmsValid = $false
    }
}
elseif ((Split-Path -Path $inputFile -Parent) -eq "")
{
    # Add default directory if only filename is given
    $inputFile = $thisWeekDir + "\" + ($inputFile -replace '"',"")
}
# Ensure we have an image type
if (($imageType -eq "auto") -and ($parmsValid -eq $true))
{
    # Tries to determine image type from input file name, otherwise returns "select"
    $imageType = Auto-Select-ImageType($inputFile)
}
if ((($imageType.Length -eq 0) -or ($imageType -eq "select")) -and ($parmsValid -eq $true))
{
    # Prompts user for image type
    $imageType = Select-ImageType($inputFile)
    if ($imageType.Length -eq 0)
    {
        $parmsValid = $false
    }
}

if ($parmsValid)
{
    Export-Slides $inputFile $imageType
}
